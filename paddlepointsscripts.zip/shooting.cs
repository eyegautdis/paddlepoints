﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shooting : MonoBehaviour
{

    public GameObject bullet;
    public GameObject bulletBlue;
    public float speed = 100f;
    public static int gamestarted =0;

   

    // Start is called before the first frame update
    //void Start()
    //{
        //Start the coroutine we define below named ExampleCoroutine.
        //StartCoroutine(ExampleCoroutine());
    //}

    // Update is called once per frame

// Starting in 2 seconds.
// a projectile will be launched every 0.3 seconds
    void Start()
    {
        
        //if (Input.anyKey)
        //{
        //InvokeRepeating("ShootingBall", 5.0f, 1.5f);
        InvokeRepeating("ShootRandomBall", 5.0f, 1.5f);
        //InvokeRepeating("PickRandomBall", 5.0f, 1.5f);
        
    }

void ShootingBall()
    {
    
        //yield return new WaitForSeconds(3);
        GameObject instBullet = Instantiate(bullet,transform.position,Quaternion.identity) as GameObject;
            Rigidbody instBulletRigidbody = instBullet.GetComponent<Rigidbody>();
            instBulletRigidbody.AddForce(Vector3.forward * speed);
    
        
    }

    void ShootRandomBall()
    {
        //get a random number
        //RandomOption = Random.Range(1,2);

        var randomInt = Random.Range(0,100);
        if (randomInt < 50 && gamestarted > 0 )
        {
            Debug.Log("Red Ball Picked Randomly");
            GameObject instBullet = Instantiate(bullet,transform.position,Quaternion.identity) as GameObject;
            Rigidbody instBulletRigidbody = instBullet.GetComponent<Rigidbody>();
            instBulletRigidbody.AddForce(-Vector3.forward * speed);
        }
 
        if (randomInt > 50 && gamestarted > 0 )
        {
            Debug.Log("Blue Ball Picked Randomly");
            GameObject instBullet = Instantiate(bulletBlue,transform.position,Quaternion.identity) as GameObject;
            Rigidbody instBulletRigidbody = instBullet.GetComponent<Rigidbody>();
            instBulletRigidbody.AddForce(-Vector3.forward * speed);
        }
    }

}
    
        //if(Input.GetKeyDown(KeyCode.Space)){
            //GameObject instBullet = Instantiate(bullet,transform.position,Quaternion.identity) as GameObject;
            //Rigidbody instBulletRigidbody = instBullet.GetComponent<Rigidbody>();
            //instBulletRigidbody.AddForce(Vector3.forward * speed);
            //yield return new WaitForSeconds(1.5f);
        //}
    //}

