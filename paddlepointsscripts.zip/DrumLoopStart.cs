﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrumLoopStart : MonoBehaviour
{
    public AudioSource audioSource2;
    public AudioClip drumloop;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
void OnCollisionEnter(Collision other)
    {

         if(other.gameObject.tag == "interactable")
        {
            //print("Paddle Has Moved - Starting Game");
            audioSource2 = GetComponent<AudioSource>();
            audioSource2.clip = drumloop;
            audioSource2.Play();
            //shooting.gamestarted = 1;
            //Rigidbody rbComp = paddle.GetComponent<Rigidbody>();
            //rbComp.useGravity = true;
            //startbutton.SetActive (false);
        }
    }   
}
