﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Timer : MonoBehaviour
{
     float timeLeft = 60.0f;
     
     public Text time;
     //public GameObject startbuttonretry;
     public GameObject startbuttonreplay;
     void Start()
     {
         time = GetComponent<Text> ();
     }
 
     
     void Update()
     {
         if(shooting.gamestarted > 0){

         timeLeft -= Time.deltaTime;
         time.text = "Time:" + Mathf.Round(timeLeft);

         if(timeLeft < 1)
         {
             timeLeft = 60.0f;
             time.text = "Time:" + Mathf.Round(timeLeft);
             shooting.gamestarted = 0;
             Score.scoreValue =0;
             startbuttonreplay.SetActive (true);
             //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
             //Instantiate(BeachBat1,Vector3(0,0,0),Quaternion.identity);
         }
     }
     }

 }
