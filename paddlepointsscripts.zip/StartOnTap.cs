﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartOnTap : MonoBehaviour
{
    public GameObject paddle;
    public GameObject startbutton;
    public AudioSource audioSource;
    //public AudioSource audioSource2;
    public AudioClip ballhit;
    //public AudioClip drumloop;

    public Rigidbody rb;
    Vector3 originalPos;
    // Start is called before the first frame update

void Start() {
        originalPos = new Vector3(paddle.transform.position.x, paddle.transform.position.y, paddle.transform.position.z);
        rb = GetComponent<Rigidbody>();
 //alternatively, just: originalPos = gameObject.transform.position;
            }

void OnCollisionEnter(Collision other)
    {

         if(other.gameObject.tag == "startbutton")
        {
            print("Paddle Has Moved - Starting Game");
            //audioSource2 = GetComponent<AudioSource>();
            //audioSource2.clip = drumloop;
            //audioSource2.Play();
            shooting.gamestarted = 1;
            //Rigidbody rbComp = paddle.GetComponent<Rigidbody>();
            //rbComp.useGravity = true;
            startbutton.SetActive (false);
        }
        if(other.gameObject.tag == "ballreturn")
        {
            //rb.transform.eulerRotation = new Vector3(0,0,0);
            //rb.angularVelocity.magnitude *= Vector3.zero;
            rb.velocity = new Vector3(0, 0, 0);
            paddle.transform.position = originalPos;
            //paddle.transform.Rotate(0f, 0f, 0f);
        }
        if(other.gameObject.tag == "Red" || other.gameObject.tag == "Blue")
        {
            //print("playing BOING");
            audioSource = GetComponent<AudioSource>();
            audioSource.clip = ballhit;
            audioSource.Play();
        }
        
        //}
        //}
    

    // Update is called once per frame
    }
}

