﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallCleanup : MonoBehaviour
{
 void OnCollisionEnter(Collision other)
 {
        if(other.gameObject.tag == "Red" || other.gameObject.tag == "Blue")
        {
         Score.scoreValue -= 1;
         Destroy(other.gameObject);
         print("Ball Hit Plane");
        }
    
    }
 
}

     
     
