﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public static int scoreValue =0;
    public static int bestscoreValue =0;
    Text score;
    Text bestscore;

    // Start is called before the first frame update
    void Start()
    {
        score = GetComponent<Text> ();
        bestscore = GetComponent<Text> ();
    }

    // Update is called once per frame
    void Update()
    {
        score.text = "       Current:" + scoreValue + "   Best:" + bestscoreValue;
        if(scoreValue > bestscoreValue)
        {
            bestscoreValue = scoreValue;
        }
        if(scoreValue < 0)
        {
            scoreValue =0;
        }
    }
}
