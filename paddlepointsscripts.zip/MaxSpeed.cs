﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MaxSpeed : MonoBehaviour
{
public float maxSpeed;

      void update()
      {
            //rigidbody.velocity = Vector3.ClampMagnitude(rigidbody.velocity, maxSpeed);
      }

}
