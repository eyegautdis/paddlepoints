﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalScriptRed : MonoBehaviour
{
void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.tag == "Red")
        {
            Score.scoreValue += 1;
         Destroy(other.gameObject);
         print("RED Ball Hit RED GOAL");
        }
        if(other.gameObject.tag == "Blue")
        {
                Score.scoreValue -= 1;
                Destroy(other.gameObject);
                print("BLUE Ball Hit RED GOAL - Points Reduced");
        }

    }
}