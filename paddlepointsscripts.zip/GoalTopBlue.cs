﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalTopBlue : MonoBehaviour
{
void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.tag == "Blue")
        {
            Score.scoreValue += 3;
         Destroy(other.gameObject);
         print("BLUE Ball Hit BLUE GOAL");
        }
        if(other.gameObject.tag == "Red")
        {
            Score.scoreValue -= 3;
         Destroy(other.gameObject);
         print("RED Ball Hit BLUE GOAL - Points Reduced");
        }

    }
}